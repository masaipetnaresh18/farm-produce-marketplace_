from flask import Flask, render_template, request, redirect, url_for
import sqlite3

app = Flask(__name__)
DATABASE = "marketplace.db"


def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db()

    conn.execute("""
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            farmer_name TEXT NOT NULL,
            name TEXT NOT NULL,
            quantity INTEGER NOT NULL,
            price REAL NOT NULL,
            description TEXT,
            icon TEXT DEFAULT '🌾'
        )
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id INTEGER NOT NULL,
            buyer_name TEXT NOT NULL,
            quantity INTEGER NOT NULL,
            total_price REAL NOT NULL,
            status TEXT DEFAULT 'Pending',
            FOREIGN KEY(product_id) REFERENCES products(id)
        )
    """)

    # Add sample products the first time the database is created.
    count = conn.execute("SELECT COUNT(*) AS c FROM products").fetchone()["c"]

    if count == 0:
        sample_products = [
            ("Ravi Kumar", "Fresh Tomatoes", 120, 38, "Farm-fresh red tomatoes, harvested this week.", "🍅"),
            ("Lakshmi Farms", "Organic Rice", 250, 62, "Premium naturally grown rice from local farms.", "🌾"),
            ("Suresh Reddy", "Green Chillies", 80, 55, "Crisp and spicy green chillies.", "🌶️"),
            ("Anitha Farm", "Fresh Mangoes", 150, 90, "Sweet seasonal mangoes, carefully packed.", "🥭"),
            ("Green Valley", "Potatoes", 200, 32, "Clean, fresh potatoes suitable for home and restaurants.", "🥔"),
            ("Meena Organics", "Carrots", 100, 48, "Fresh crunchy carrots grown without harsh chemicals.", "🥕"),
        ]

        conn.executemany("""
            INSERT INTO products
            (farmer_name, name, quantity, price, description, icon)
            VALUES (?, ?, ?, ?, ?, ?)
        """, sample_products)

    conn.commit()
    conn.close()


@app.route("/")
def home():
    conn = get_db()
    products = conn.execute(
        "SELECT * FROM products ORDER BY id DESC"
    ).fetchall()
    conn.close()
    return render_template("index.html", products=products)


@app.route("/add-product", methods=["GET", "POST"])
def add_product():
    if request.method == "POST":
        farmer_name = request.form["farmer_name"].strip()
        name = request.form["name"].strip()
        quantity = int(request.form["quantity"])
        price = float(request.form["price"])
        description = request.form["description"].strip()
        icon = request.form.get("icon", "🌾")

        conn = get_db()
        conn.execute("""
            INSERT INTO products
            (farmer_name, name, quantity, price, description, icon)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (farmer_name, name, quantity, price, description, icon))
        conn.commit()
        conn.close()

        return redirect(url_for("products"))

    return render_template("add_product.html")


@app.route("/products")
def products():
    conn = get_db()
    products = conn.execute(
        "SELECT * FROM products ORDER BY id DESC"
    ).fetchall()
    conn.close()
    return render_template("products.html", products=products)


@app.route("/order/<int:product_id>", methods=["POST"])
def place_order(product_id):
    buyer_name = request.form["buyer_name"].strip()
    quantity = int(request.form["quantity"])

    conn = get_db()
    product = conn.execute(
        "SELECT * FROM products WHERE id = ?", (product_id,)
    ).fetchone()

    if product is None:
        conn.close()
        return "Product not found", 404

    if quantity <= 0 or quantity > product["quantity"]:
        conn.close()
        return "Invalid quantity requested", 400

    total_price = quantity * product["price"]

    conn.execute("""
        INSERT INTO orders
        (product_id, buyer_name, quantity, total_price)
        VALUES (?, ?, ?, ?)
    """, (product_id, buyer_name, quantity, total_price))

    conn.execute("""
        UPDATE products
        SET quantity = quantity - ?
        WHERE id = ?
    """, (quantity, product_id))

    conn.commit()
    conn.close()

    return redirect(url_for("view_orders"))


@app.route("/orders")
def view_orders():
    conn = get_db()
    orders = conn.execute("""
        SELECT
            orders.id,
            orders.buyer_name,
            orders.quantity,
            orders.total_price,
            orders.status,
            products.name AS product_name,
            products.farmer_name
        FROM orders
        JOIN products ON orders.product_id = products.id
        ORDER BY orders.id DESC
    """).fetchall()
    conn.close()

    return render_template("orders.html", orders=orders)


if __name__ == "__main__":
    init_db()
    app.run(debug=True)
